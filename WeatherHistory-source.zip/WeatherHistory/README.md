# Weather History — Android starter project

A first native Android implementation of the Weather History concept.

## Included in this first build

- Romanian-first home screen.
- Current weather card with temperature, apparent temperature, humidity, precipitation and wind.
- Automatic same-calendar-day comparison for the previous 1, 2, 5 or 10 years.
- Historical daily maximum/minimum temperature, precipitation, wind and weather condition.
- City search using Open-Meteo Geocoding; Piacenza is the initial saved location.
- Saved location and comparison period using Android SharedPreferences.
- Loading and error states, manual refresh, and a simple temperature-context summary.

## Data services

- Current conditions and today's daily values: Open-Meteo Forecast API.
- Historical daily values: Open-Meteo Historical Weather API.
- City lookup: Open-Meteo Geocoding API.

Historical archive values can be reanalysis/modelled data rather than direct observations from a nearby weather station. The app currently includes an explanatory note and should retain clear source attribution in production.

## Open and build

1. Install Android Studio (current stable version) with Android SDK 35 and JDK 17.
2. Open this `WeatherHistory` folder as an existing Android Studio project.
3. Allow Gradle to sync and download the Android Gradle Plugin and dependencies.
4. Run the `app` configuration on an Android device or emulator.
5. To create an installable APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. For Google Play, create a signed Android App Bundle (AAB) from **Build → Generate Signed Bundle / APK**.

This environment does not have Android SDK/Gradle installed, so an APK has not been compiled here. The deliverable is the Android Studio source project, not an APK.

## Before a public release

- Add automated tests and verify the archive date matching, including leap-day behavior.
- Add proper app icon, screenshots, privacy policy and Play listing assets.
- Review API attribution, rate limits and terms for the intended distribution scale.
- Add robust localization (Romanian and Italian first), accessibility, offline cache and location permission flow.
- Add a proper settings screen and user-selectable units.
- Test on multiple Android versions and screen sizes.
- Complete Google Play's current developer verification, data safety and testing requirements.

## Package

`com.weatherhistory.app`

Current version: `0.1.0` (starter)
