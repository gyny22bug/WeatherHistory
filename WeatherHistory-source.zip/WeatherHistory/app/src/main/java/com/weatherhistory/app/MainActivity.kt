package com.weatherhistory.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Ink = Color(0xFF16324F)
private val Muted = Color(0xFF6C8297)
private val Sky = Color(0xFFE8F3FF)
private val SurfaceWhite = Color(0xFFFFFFFF)
private val Page = Color(0xFFF5F8FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WeatherHistoryApp() }
    }
}

data class Place(val name: String, val latitude: Double, val longitude: Double)
data class CurrentWeather(
    val temperature: Double, val feelsLike: Double, val humidity: Int,
    val wind: Double, val rain: Double, val code: Int,
    val max: Double, val min: Double
)
data class HistoricDay(
    val year: Int, val max: Double?, val min: Double?,
    val rain: Double?, val wind: Double?, val code: Int?
)
data class WeatherScreenData(val current: CurrentWeather, val history: List<HistoricDay>)

@Composable
fun WeatherHistoryApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("weather_history", 0) }
    var place by remember {
        mutableStateOf(Place(
            prefs.getString("place_name", "Piacenza") ?: "Piacenza",
            prefs.getString("place_lat", "45.0522")!!.toDoubleOrNull() ?: 45.0522,
            prefs.getString("place_lon", "9.6929")!!.toDoubleOrNull() ?: 9.6929
        ))
    }
    var years by remember { mutableIntStateOf(prefs.getInt("years", 2)) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var screenData by remember { mutableStateOf<WeatherScreenData?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var showPlaceDialog by remember { mutableStateOf(false) }

    LaunchedEffect(place, years, refreshKey) {
        loading = true
        error = null
        try {
            screenData = loadWeather(place, years)
        } catch (e: Exception) {
            error = e.message ?: "Nu am putut încărca datele meteo. Verifică internetul."
        }
        loading = false
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF276A9B), secondary = Color(0xFF68A9D8), background = Page,
        surface = SurfaceWhite, onSurface = Ink
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Page) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 30.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("Weather History", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("Vremea de azi, pusă în perspectivă", fontSize = 13.sp, color = Muted)
                        }
                        IconButton(onClick = { refreshKey++ }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reîncarcă", tint = Ink)
                        }
                    }
                }
                item {
                    CurrentWeatherCard(place, screenData?.current, loading, onPlaceClick = { showPlaceDialog = true })
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Aceeași zi în anii trecuți", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text("ISTORIC", fontSize = 10.sp, letterSpacing = 1.2.sp, color = Muted, fontWeight = FontWeight.Bold)
                        }
                        Text("Comparația se actualizează automat. Nu trebuie să alegi fiecare an.", fontSize = 12.sp, color = Muted)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf(1, 2, 5, 10).forEach { count ->
                                FilterChip(
                                    selected = years == count,
                                    onClick = { years = count; prefs.edit().putInt("years", count).apply() },
                                    label = { Text(if (count == 1) "1 an" else "$count ani") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
                if (loading && screenData == null) {
                    item { LoadingCard() }
                }
                if (error != null) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F0))) {
                            Text(error!!, modifier = Modifier.padding(16.dp), color = Color(0xFF9A332A), fontSize = 13.sp)
                        }
                    }
                }
                val history = screenData?.history.orEmpty()
                if (history.isNotEmpty()) {
                    items(history) { day -> HistoricRow(day) }
                } else if (!loading && error == null) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = SurfaceWhite)) {
                            Text("Nu avem încă date istorice disponibile pentru această zi.", modifier = Modifier.padding(16.dp), color = Muted)
                        }
                    }
                }
                if (screenData != null) {
                    item { ClimateNote(screenData!!.current, history) }
                }
                item {
                    Text("Date meteo: Open-Meteo · Arhiva istorică poate folosi date de reanaliză, nu doar măsurători de la stații.", fontSize = 10.sp, color = Muted, lineHeight = 14.sp)
                }
            }
        }
    }

    if (showPlaceDialog) {
        var query by remember { mutableStateOf(place.name) }
        var searching by remember { mutableStateOf(false) }
        var dialogError by remember { mutableStateOf<String?>(null) }
        val scope = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { if (!searching) showPlaceDialog = false },
            title = { Text("Alege localitatea") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Oraș sau localitate") }, singleLine = true)
                    if (searching) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    dialogError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(enabled = !searching && query.isNotBlank(), onClick = {
                    searching = true
                    dialogError = null
                    scope.launch {
                        try {
                            val match = searchPlace(query)
                            if (match == null) dialogError = "Nu am găsit localitatea. Încearcă un alt nume."
                            else {
                                place = match
                                prefs.edit().putString("place_name", match.name).putString("place_lat", match.latitude.toString()).putString("place_lon", match.longitude.toString()).apply()
                                showPlaceDialog = false
                            }
                        } catch (e: Exception) {
                            dialogError = e.message ?: "Căutarea nu a reușit."
                        } finally { searching = false }
                    }
                }) { Text("Caută") }
            },
            dismissButton = { TextButton(onClick = { showPlaceDialog = false }) { Text("Anulează") } }
        )
    }
}

@Composable
private fun CurrentWeatherCard(place: Place, weather: CurrentWeather?, loading: Boolean, onPlaceClick: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFD9ECFF), Color(0xFFF0F7FF), Color(0xFFE4F1FF))))
            .padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("ro"))).replaceFirstChar { it.uppercase() }, color = Color(0xFF426582), fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF426582), modifier = Modifier.size(16.dp))
                        Text(place.name, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                TextButton(onClick = onPlaceClick) { Icon(Icons.Default.Search, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Schimbă") }
            }
            if (loading && weather == null) {
                Box(Modifier.fillMaxWidth().height(110.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color(0xFF276A9B)) }
            } else if (weather != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(weatherIcon(weather.code), fontSize = 52.sp)
                        Text(weatherDescription(weather.code), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Text("Se simt ca ${weather.feelsLike.roundToIntSafe()}°", color = Color(0xFF58758E), fontSize = 12.sp)
                    }
                    Text("${weather.temperature.roundToIntSafe()}°", color = Ink, fontSize = 66.sp, fontWeight = FontWeight.Light, letterSpacing = (-3).sp)
                }
                Text("Max ${weather.max.roundToIntSafe()}°   ·   Min ${weather.min.roundToIntSafe()}°", color = Color(0xFF426582), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    WeatherMetric("💧", "${weather.humidity}%", "Umiditate", Modifier.weight(1f))
                    WeatherMetric("🌧️", "${formatOne(weather.rain)} mm", "Precipitații", Modifier.weight(1f))
                    WeatherMetric("💨", "${formatOne(weather.wind)} km/h", "Vânt", Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun WeatherMetric(icon: String, value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .65f)).padding(vertical = 10.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 17.sp)
        Text(value, color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(label, color = Muted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun HistoricRow(day: HistoricDay) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = SurfaceWhite), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(day.year.toString(), color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(weatherDescription(day.code ?: -1), color = Muted, fontSize = 12.sp)
                Text("🌧 ${day.rain?.let { formatOne(it) } ?: "—"} mm     💨 ${day.wind?.let { formatOne(it) } ?: "—"} km/h", color = Muted, fontSize = 11.sp)
            }
            Text(weatherIcon(day.code ?: -1), fontSize = 27.sp)
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text("${day.max?.roundToIntSafe()?.toString() ?: "—"}°", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("min ${day.min?.roundToIntSafe()?.toString() ?: "—"}°", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ClimateNote(current: CurrentWeather, history: List<HistoricDay>) {
    val previous = history.mapNotNull { it.max }
    val average = if (previous.isNotEmpty()) previous.average() else null
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF5EE))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Pe scurt", color = Color(0xFF24583B), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (average != null) {
                val difference = current.max - average
                val phrase = when {
                    difference > 1.0 -> "Astăzi este mai cald decât media maximelor din perioada comparată."
                    difference < -1.0 -> "Astăzi este mai rece decât media maximelor din perioada comparată."
                    else -> "Temperatura maximă de astăzi este apropiată de media perioadei comparate."
                }
                Text(phrase, color = Color(0xFF37664B), fontSize = 13.sp)
                Text("Media maximelor istorice: ${formatOne(average)}°C", color = Color(0xFF37664B), fontSize = 11.sp)
            } else Text("Comparația va apărea când sunt disponibile date istorice.", color = Color(0xFF37664B), fontSize = 13.sp)
        }
    }
}

@Composable
private fun LoadingCard() {
    Card(shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(12.dp)); Text("Încărcăm vremea și arhiva istorică…", color = Muted, fontSize = 13.sp)
        }
    }
}

private suspend fun loadWeather(place: Place, years: Int): WeatherScreenData = withContext(Dispatchers.IO) {
    val currentUrl = "https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}" +
        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&timezone=auto&forecast_days=1"
    val currentJson = getJson(currentUrl)
    val current = currentJson.getJSONObject("current")
    val daily = currentJson.getJSONObject("daily")
    val today = LocalDate.now()
    val currentWeather = CurrentWeather(
        temperature = current.optDouble("temperature_2m", 0.0),
        feelsLike = current.optDouble("apparent_temperature", current.optDouble("temperature_2m", 0.0)),
        humidity = current.optInt("relative_humidity_2m", 0),
        wind = current.optDouble("wind_speed_10m", 0.0),
        rain = current.optDouble("precipitation", 0.0),
        code = current.optInt("weather_code", 0),
        max = daily.getJSONArray("temperature_2m_max").optDouble(0),
        min = daily.getJSONArray("temperature_2m_min").optDouble(0)
    )

    val start = today.minusYears(years.toLong()).format(DateTimeFormatter.ISO_DATE)
    val end = today.minusDays(1).format(DateTimeFormatter.ISO_DATE)
    val archiveUrl = "https://archive-api.open-meteo.com/v1/archive?latitude=${place.latitude}&longitude=${place.longitude}" +
        "&start_date=$start&end_date=$end&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&timezone=auto"
    val archive = getJson(archiveUrl).getJSONObject("daily")
    val dates = archive.getJSONArray("time")
    val max = archive.getJSONArray("temperature_2m_max")
    val min = archive.getJSONArray("temperature_2m_min")
    val rain = archive.getJSONArray("precipitation_sum")
    val wind = archive.getJSONArray("wind_speed_10m_max")
    val codes = archive.getJSONArray("weather_code")
    val found = mutableMapOf<Int, HistoricDay>()
    for (i in 0 until dates.length()) {
        val date = LocalDate.parse(dates.getString(i))
        if (date.monthValue == today.monthValue && date.dayOfMonth == today.dayOfMonth) {
            found[date.year] = HistoricDay(date.year, max.optNullableDouble(i), min.optNullableDouble(i), rain.optNullableDouble(i), wind.optNullableDouble(i), codes.optInt(i))
        }
    }
    val history = (1..years).mapNotNull { offset -> found[today.year - offset] }
    WeatherScreenData(currentWeather, history)
}

private suspend fun searchPlace(query: String): Place? = withContext(Dispatchers.IO) {
    val encoded = URLEncoder.encode(query.trim(), "UTF-8")
    val json = getJson("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=ro&format=json")
    val results = json.optJSONArray("results") ?: return@withContext null
    if (results.length() == 0) return@withContext null
    val result = results.getJSONObject(0)
    val city = result.optString("name", query.trim())
    val region = result.optString("admin1", "")
    val country = result.optString("country", "")
    val label = listOf(city, region, country).filter { it.isNotBlank() }.distinct().joinToString(", ")
    Place(label, result.getDouble("latitude"), result.getDouble("longitude"))
}

private fun getJson(url: String): JSONObject {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15000; readTimeout = 20000; requestMethod = "GET"
        setRequestProperty("User-Agent", "WeatherHistory/0.1 Android")
    }
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("Serviciul meteo a răspuns cu eroarea $code.")
        return JSONObject(body)
    } finally { connection.disconnect() }
}

private fun weatherIcon(code: Int): String = when (code) {
    0 -> "☀️"
    1, 2 -> "🌤️"
    3 -> "☁️"
    45, 48 -> "🌫️"
    51, 53, 55, 56, 57 -> "🌦️"
    61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
    71, 73, 75, 77, 85, 86 -> "❄️"
    95, 96, 99 -> "⛈️"
    else -> "🌡️"
}

private fun weatherDescription(code: Int): String = when (code) {
    0 -> "Senin"
    1 -> "Predominant senin"
    2 -> "Parțial noros"
    3 -> "Înnorat"
    45, 48 -> "Ceață"
    51, 53, 55, 56, 57 -> "Burniță"
    61, 63, 65, 66, 67, 80, 81, 82 -> "Ploaie"
    71, 73, 75, 77, 85, 86 -> "Ninsoare"
    95, 96, 99 -> "Furtună"
    else -> "Condiții variabile"
}

private fun org.json.JSONArray.optNullableDouble(index: Int): Double? = if (isNull(index)) null else optDouble(index).takeIf { !it.isNaN() }
private fun Double.roundToIntSafe(): Int = kotlin.math.round(this).toInt()
private fun formatOne(value: Double): String = String.format(Locale.getDefault(), "%.1f", value)
